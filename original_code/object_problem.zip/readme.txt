Here's the lowdown.

1. To execute the main script, type "ant" at the MATLAB prompt,
   making sure the directory with all the necessary scripts is in the path.
2. When the GUI comes up, hit the button marked <S T A R T>.
3. Wait a while, and eventually the error will happen.

that's it!  happy hunting.

-Brian

brian.brewington@dartmouth.edu
(603) 646-2577

Dartmouth College
8000 Cummings Hall
Hanover, NH 03755-8000

